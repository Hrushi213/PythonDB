import pymysql
con=pymysql.connect(host='bnydiqqlf9cnehvu2lmc-mysql.services.clever-cloud.com',user='urnljcidzqqaqiqv',password='fzXxWZtLLrVr6zHHHySb',database='bnydiqqlf9cnehvu2lmc')
curs=con.cursor()
try:    
    cd=int(input("Enter Books Code:"))
    curs.execute("select * from books where bookcode=%d" %cd)
    data=curs.fetchone()
    if data:
        print(data)
    else:
        print("Book Not Found")
except Exception as e:

    print("Error ",e)
con.close()
