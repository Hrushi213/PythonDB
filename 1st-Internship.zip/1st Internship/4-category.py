import pymysql

con=pymysql.connect(host='bnydiqqlf9cnehvu2lmc-mysql.services.clever-cloud.com',user='urnljcidzqqaqiqv',password='fzXxWZtLLrVr6zHHHySb',database='bnydiqqlf9cnehvu2lmc')
curs=con.cursor()
ct=input("Enter a Category:")
curs.execute("select * from books where Category='%s'"%ct)
data=curs.fetchall()
for rec in data:
    print(rec[1])

con.close()

