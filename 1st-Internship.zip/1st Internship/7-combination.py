import pymysql
con=pymysql.connect(host='bnydiqqlf9cnehvu2lmc-mysql.services.clever-cloud.com',user='urnljcidzqqaqiqv',password='fzXxWZtLLrVr6zHHHySb',database='bnydiqqlf9cnehvu2lmc')
curs=con.cursor()
try:
    at=input("Enter Author Name:")
    pb=int(input("Enter Publication:"))
    curs.execute("select * from books where author='%s' and publication=%d"%(at,pb))
    data=curs.fetchmany()
    if data:
        print(data)
    else:
        print("Book Not Found")
except Exception as e:
    print("Error",e)

finally:
    con.close()
