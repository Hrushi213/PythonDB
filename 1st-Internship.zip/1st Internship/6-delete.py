import pymysql
con=pymysql.connect(host='bnydiqqlf9cnehvu2lmc-mysql.services.clever-cloud.com',user='urnljcidzqqaqiqv',password='fzXxWZtLLrVr6zHHHySb',database='bnydiqqlf9cnehvu2lmc')

curs=con.cursor()
try:
    bc=int(input("Enter Book Code:"))
    curs.execute("select * from books where bookcode=%d"%bc)
    data=curs.fetchall()
    
    if data:
        print(data)
        d=input("Do You Want To Delete This Book (Y/N):")
        if d.upper()=='Y':
            curs.execute("delete from books where bookcode=%d"%bc)
            
            print("Book Deleted")
        else:
            print("OK")
    else:
        print("Book Does Not Exist")
    

except Exception as e:
    print("Error",e)

finally:
    con.commit()
    con.close()
