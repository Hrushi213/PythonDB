import pymysql
con=pymysql.connect(host='bnydiqqlf9cnehvu2lmc-mysql.services.clever-cloud.com',user='urnljcidzqqaqiqv',password='fzXxWZtLLrVr6zHHHySb',database='bnydiqqlf9cnehvu2lmc')
curs=con.cursor()
try:
    code=int(input("Enter Book Code:"))
    name=input("Enter Book Name:")
    category=input("Enter Category:")
    author=input("Enter Author Name:")
    publication=input("Enter Publication:")
    edition=int(input("Enter Edition:"))
    price=float(input("Enter Price:"))

    curs.execute("insert into books values(%d,'%s','%s','%s','%s',%d,%.2f)" %(code,name,category,author,publication,edition,price))
    con.commit()

    
except Exception as e:
    print("Error",e)

con.close()