import pymysql

con=pymysql.connect(host='bnydiqqlf9cnehvu2lmc-mysql.services.clever-cloud.com',user='urnljcidzqqaqiqv',password='fzXxWZtLLrVr6zHHHySb',database='bnydiqqlf9cnehvu2lmc')
curs=con.cursor()
try:
    bc=int(input("Enter bookcode:"))
    rw=input("Write a Review:")
    curs.execute("select * from books where bookcode=%d"%bc)
    data=curs.fetchone()
    if data:
        curs.execute("update books set review='%s'"%rw)
        print("Review Added")
        con.commit()
    else:
        print("Book Does Not Exist")
except Exception as e:
    print("Error",e)

