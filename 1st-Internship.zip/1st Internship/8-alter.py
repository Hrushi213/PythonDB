import pymysql

con=pymysql.connect(host='bnydiqqlf9cnehvu2lmc-mysql.services.clever-cloud.com',user='urnljcidzqqaqiqv',password='fzXxWZtLLrVr6zHHHySb',database='bnydiqqlf9cnehvu2lmc')
try:
    curs=con.cursor()
    curs.execute("alter table books add review varchar(500)")
    con.commit()
    print("New Column Added")
except Exception as e:
    print("Error",e)
finally:
    con.close()

